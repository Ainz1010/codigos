from django.shortcuts import render

# Create your views here.
def usuario(request):
    html = 'usuario/usuario.html'
    contexto = {}
    return render(request,html,contexto)