# exercicio/urls.py
from django.urls import path
from .views import usuario

urlpatterns = [
    path('usuario/', usuario, name='pagina_usuario'),
    # Adicione outras URLs aqui, se necessário
]
