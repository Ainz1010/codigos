# exercicio/urls.py
from django.urls import path
from .views import criar_exercicio

urlpatterns = [
    path('criar/', criar_exercicio, name='criar_exercicio'),
    # Adicione outras URLs aqui, se necessário
]
