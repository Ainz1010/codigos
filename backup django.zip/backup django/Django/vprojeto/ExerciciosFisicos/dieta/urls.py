# exercicio/urls.py
from django.urls import path
from .views import dieta

urlpatterns = [
    path('dieta/', dieta, name='pagina_dieta'),
    # Adicione outras URLs aqui, se necessário
]
