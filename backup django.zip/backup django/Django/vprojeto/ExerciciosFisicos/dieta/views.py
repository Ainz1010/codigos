from django.shortcuts import render

# Create your views here.
def dieta(request):
    html = 'dieta/dieta.html'
    contexto = {}
    return render(request,html,contexto)