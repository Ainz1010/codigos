from django.shortcuts import render

# Create your views here.
def equipamento(request):
    html = 'equipamento/equipamento.html'
    contexto = {}
    return render(request,html,contexto)