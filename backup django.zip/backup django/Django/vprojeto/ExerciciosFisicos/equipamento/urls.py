# exercicio/urls.py
from django.urls import path
from .views import equipamento

urlpatterns = [
    path('equipamento/', equipamento, name='pagina_equipamentos'),
    # Adicione outras URLs aqui, se necessário
]
