# exercicio/urls.py
from django.urls import path
from .views import treino

urlpatterns = [
    path('treino/', treino, name='pagina_treino'),
    # Adicione outras URLs aqui, se necessário
]
