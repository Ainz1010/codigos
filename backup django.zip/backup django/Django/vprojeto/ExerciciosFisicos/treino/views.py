from django.shortcuts import render

# Create your views here.
def treino(request):
    html = 'treino/treino.html'
    contexto = {}
    return render(request,html,contexto)