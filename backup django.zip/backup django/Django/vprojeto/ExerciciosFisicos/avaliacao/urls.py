# exercicio/urls.py
from django.urls import path
from .views import avaliacao

urlpatterns = [
    path('avaliacao/', avaliacao, name='pagina_avaliações'),
    # Adicione outras URLs aqui, se necessário
]
