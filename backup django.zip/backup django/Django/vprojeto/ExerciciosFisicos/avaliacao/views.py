from django.shortcuts import render

# Create your views here.
def avaliacao(request):
    html = 'avaliacao/avaliacao.html'
    contexto = {}
    return render(request,html,contexto)