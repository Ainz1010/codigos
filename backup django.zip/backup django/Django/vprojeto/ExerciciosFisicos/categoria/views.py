from django.shortcuts import render

# Create your views here.
def categoria(request):
    html = 'categoria/categoria.html'
    contexto = {}
    return render(request,html,contexto)