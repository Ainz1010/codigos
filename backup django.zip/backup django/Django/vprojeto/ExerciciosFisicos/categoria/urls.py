# exercicio/urls.py
from django.urls import path
from .views import categoria

urlpatterns = [
    path('categoria/', categoria, name='categoria_dos_exercicios'),
    # Adicione outras URLs aqui, se necessário
]
